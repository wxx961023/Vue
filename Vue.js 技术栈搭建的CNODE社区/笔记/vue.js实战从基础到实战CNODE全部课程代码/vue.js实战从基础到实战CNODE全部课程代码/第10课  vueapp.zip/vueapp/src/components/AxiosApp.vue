<template>
<h3>我是AXIOS，用来发送请求和拦截响应</h3>
</template>

<script>
    export default {
        name: "AxiosApp"
    }
</script>

<style scoped>

</style>
